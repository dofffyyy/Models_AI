// Initialize variables to store the map and destination points
let map;
let destinations = [];

// Function to create the map
function createMap() {
    map = document.getElementById('map');
    map.addEventListener('click', handleMapClick);
}

// Function to handle map clicks and add destination points
function handleMapClick(event) {
    const rect = map.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    addDestination(x, y);
}

// Function to add a destination point on the map
function addDestination(x, y) {
    const destination = document.createElement('div');
    destination.classList.add('destination');
    destination.style.left = `${x}px`;
    destination.style.top = `${y}px`;
    map.appendChild(destination);
    destinations.push({ x, y });
}

// Call the createMap function when the DOM is ready
document.addEventListener('DOMContentLoaded', createMap);
