function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  async function main() {
    console.log("Start");
    await sleep(2000); // Sleep for 2000 milliseconds (2 seconds)
    console.log("After 2 seconds");
    await sleep(3000); // Sleep for 3000 milliseconds (3 seconds)
    console.log("After 3 seconds");
  }
  
  main();
  