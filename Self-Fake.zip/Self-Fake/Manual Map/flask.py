from flask import Flask
from flask_socketio import SocketIO
import RPi.GPIO as GPIO
import time

app = Flask('robo_control_app')
# Setup GPIO pins
# Define the GPIO pins for your motors
@app.route('\index.html')
def index():
    return render_template('index.html')

GPIO.setmode(GPIO.BCM)
left_motor_pin = 17  # GPIO pin for left motor
right_motor_pin = 18  # GPIO pin for right motor
GPIO.setup(left_motor_pin, GPIO.OUT)
GPIO.setup(right_motor_pin, GPIO.OUT)

left_motor = GPIO.PWM(left_motor_pin, 100)
right_motor = GPIO.PWM(right_motor_pin, 100)
left_motor.start(0)
right_motor.start(0)
#functions to move directions
def forward():
    left_motor.ChangeDutyCycle(50)
    right_motor.ChangeDutyCycle(50)
def backward():
    left_motor.ChangeDutyCycle(-50)
    right_motor.ChangeDutyCycle(-50)
def right():
    left_motor.ChangeDutyCycle(50)
    right_motor.ChangeDutyCycle(-50)
def left():
     left_motor.ChangeDutyCycle(-50)
     right_motor.ChangeDutyCycle(50)
def stop():
    left_motor.ChangeDutyCycle(0)
    right_motor.ChangeDutyCycle(0)
socketio = SocketIO(app)

# Function to handle incoming WebSocket messages
@socketio.on('message')
def handle_message(message):
    payload = json.loads(message)
    command = payload.get('command')
    if command:
        # Process the command and move the robot accordingly
        move_robot(command)


# Function to move the robot based on the received command
def move_robot(command):
    # Implement the logic to control the robot's movements here
    if command == 1:
        forward()
        time.sleep(5)
    elif command == 2:
        # set_motor_direction(False, False)#backward
        pass
    elif command == 3:
        pass
    elif command == 4:
        pass
    elif command == 5:
        pass

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=your_chosen_port)
